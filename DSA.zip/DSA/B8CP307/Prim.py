import networkx as nx
import random as rand
import heapq as heap

class Prim():
    def __init__(self):
        pass
                
        
    def mst(self, Graph, Q):
        # list to store the mst
        mst = []
        t_nodes = []
        INF = 999999
        
        start = rand.choice(list(Graph.nodes))
        
        preds = {}
        preds[start] = None
        
        # initalize distance from start to be 0
        # key = priority
        # value = city
        # item, priority
        dist = {}
        dist[start] = 0
        Q.put(start, dist[start])
               
        # initalize each node in the graph to have no predecessor 
        # and distance to be infinity
        for node in (list(Graph.nodes)):
            if node != start:
                dist[node] = INF
                # need to put all nodes into a priority queue...
                Q.put(node, dist[node]) 
        
        
        while Q.size() > 0 :
            pri, v = Q.pop()
           
            # index error handling
            if v is not None:
                # connect current node to closest thing in tree already
                if v not in t_nodes:
                    t_nodes.append(v)
                    if len(t_nodes) > 1:
                        mst.append((v , preds[v]))
            
                neighbors = list(Graph.neighbors(v))
            
                for neighbor in neighbors:
                    weight = Graph[v][neighbor]['weight']
                    
                    if weight < dist[neighbor]:
                            Q.put(neighbor, weight)
                            preds[neighbor] = v
                            dist[neighbor] = weight         
        
        return mst
    