import tkinter as tk
from tkinter import font
import networkx as nx
import matplotlib.pyplot as plt
from data import *
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

city_buttons_list = []
selected_cities = []
to_show = []
dict_cities = {}


d = Data()
d.data()
        
    
def city_selected(option):
    if len(selected_cities) > 4:
        welcome_msg.configure(text="Cannot select more than five cities.")
    else:   
        val = dict_cities[option]
        selected_cities.append(val)
        to_show.append(option)
        welcome_msg.configure(text="Cities selected: " + str(to_show))
        
def remove_intro_objects():
    welcome_msg.destroy()
    for cb in city_buttons_list:
        cb.destroy()
        
def show_og_graph(): 
    # remove objects from intro screen
    remove_intro_objects()
    
    gr = d.usr_input(selected_cities)
    
    # header message
    direct_select.configure(text="Complete graph of selected cities.")

    # create figure and plot the graph
    fig = plt.figure(figsize=(3, 3))
    pos = nx.spring_layout(gr, k=10)
    nx.draw(gr, pos, with_labels=True)
    labels = {e: gr.edges[e]['weight'] for e in gr.edges}
    nx.draw_networkx_edge_labels(gr, pos, edge_labels=labels)
    
    # create canvas and display figure on it
    canvas = FigureCanvasTkAgg(fig, master=window)
    canvas.draw()
    canvas.get_tk_widget().place(x=75, y=75)
    
    submit_button.destroy()
    mst_button.place(x=700, y=800)
    
def get_mst():
    # header message
    direct_select.configure(text="Step 1: Find a minimum spanning tree T.")
    
    # create figure and plot mst
    test_mst = nx.minimum_spanning_tree(test_G)
    fig = plt.figure(figsize=(3, 3))
    pos = nx.spring_layout(test_G, k=10)
    nx.draw(test_mst, pos, with_labels=True)
    labels = {e: test_mst.edges[e]['weight'] for e in test_mst.edges}
    nx.draw_networkx_edge_labels(test_mst, pos, edge_labels=labels)
    
    # create canvas and display figure on it
    canvas = FigureCanvasTkAgg(fig, master=window)
    canvas.draw()
    canvas.get_tk_widget().place(x=400, y=75)
    
    mst_button.destroy()
    perfect_matching_button.place(x=700, y=800)
    
def get_perfect_matching():
    # header message
    direct_select.configure(text="Step 2: Let O be the set of nodes with odd degree in T. Find a minimum-cost perfect matching M on O.")
    
    

# create main window
window = tk.Tk()

# set window title
window.title("TSP Chrisofides Algorithm")

# set window dimensions
window_width = 800
window_height = 800

# get screen dimensions
screen_width = window.winfo_screenwidth()
screen_height = window.winfo_screenheight()

# calculate window position
x = (screen_width - window_width) // 2
y = (screen_height - window_height) // 2 - 50

# set window position
window.geometry(f"{window_width}x{window_height}+{x}+{y}")

# welcome message to the window
custom_font = font.Font(size=20)
welcome_msg = tk.Label(window, text="Welcome to the Traveling Salesperson Problem!\nLet's find the shortest possible route that visits each city exactly once and returns to the origin city.", font=custom_font)
welcome_msg.pack()

# direction message, once user cluicks on city, this message shows list of selected cities
direct_select = tk.Label(window, text="\nSelect up to five cities.", font=custom_font)
direct_select.pack()

# a list of cities
cities = ["Denver", "Los Angeles", "Houston", "Phoenix", "Chicago",
           "NYC", "Seattle", "Portland", "New Orleans", "Orlando"]

# buttons for each option
count = 0
for city in cities:
    city_buttons = tk.Button(window, text=city, width=30, height=4, command=lambda opt=city: city_selected(opt))
    city_buttons.pack()
    city_buttons_list.append(city_buttons)
    dict_cities[city] = str(count)
    count += 1
    
# submit option
submit_button = tk.Button(window, text="Submit", width=10, height=2, command=lambda: show_og_graph())
submit_button.place(x=700, y=800)

# mst button
mst_button = tk.Button(window, text="Next", width=10, height=2, command=lambda: get_mst())

# perfect matching button
perfect_matching_button = tk.Button(window, text="Next", width=10, height=2, command=lambda: get_perfect_matching())

quit_button = tk.Button(window, text="Quit", command=window.destroy).pack()


# run the event loop
window.mainloop()