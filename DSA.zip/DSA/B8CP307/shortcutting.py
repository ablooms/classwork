def shortcutting(v_list):
    ham_tour = []
    
    for v in v_list:
        if v not in ham_tour:
            ham_tour.append(v)
            
    ham_tour.append(v_list[0])
            
    return ham_tour