import networkx as nx
import numpy as np

# return a set of vertices with odd degree
def get_odd_degree_vertices(mst_edges):
    
    # make the minimum spanning tree graph
    mst = nx.Graph()
    mst.add_edges_from(mst_edges)
    
    # a set of nodes in mst with odd degree
    O = []
    
    # get all nodes of the mst
    mst_nodes = list(mst.nodes)
    
    # loop through every node and check of degree is odd, append it to O
    for node in mst_nodes:
        if mst.degree(node) % 2 != 0:
            O.append(node)
    
    # return a set of nodes in mst with odd degree
    return O

# make a complete subgraph with the set of nodes in mst with odd degree
def get_subgraph(G, v_list):
    
    # make a read only subgraph
    comp_mst = G.subgraph(v_list)
    
    # return a mutable subgraph
    return nx.Graph(comp_mst)

# find perfect matching, not 100% minimum cost
def path_growing(G, min_edges):
    
    # make a copy of G so it won't be directly affected
    G_copy = G.copy()
    
    M1 = []
    M2 = []
    i = 1
    
    # make sure there are more than expected edges when trying to find a path
    if len(list(G_copy.edges)) > min_edges:
    
        # while there are edges in G
        while len(list(G_copy.edges)) > 0:
        
            # pick an arbitrary vertex
            x = np.random.choice(list(G_copy.nodes))
        
            # while x has neighbor
            while len(list(G_copy[x])) > 0:
            
                #  sort the neighbor list from min to max 
                ordered_weighted_edges = sorted(G_copy[x].items(), key=lambda edge: edge[1]['weight'])
            
                # min neigbor
                y = ordered_weighted_edges[0][0]
            
                # min edge with x and y
                min_edge = (x, y)
            
                # put in M1
                if i == 1:
                    M1.append(min_edge)
                
                # put in M2
                else:
                    M2.append(min_edge)
            
                # switch list
                i = 3 - i
            
                # remove x from G
                G_copy.remove_node(x)
            
                # now check y neighbors
                x = y
    
    # this means there is already perfect matching
    else:
        for edge in list(G_copy.edges):
            M1.append(edge)
    
    # return list with more items
    if len(M1) > len(M2):
        return M1
    else:
        return M2

# get total weight of all edges in in M
def get_M_weight(G, M):
    
    # initialize weight count
    weight = 0
    
    # check every edge in M
    for edge in M:
        
        # get the weight in form of dictionary
        data_dict = G.get_edge_data(edge[0], edge[1])
        
        # get the weight in int
        edge_w = data_dict['weight']
        
        # add it to min weight
        weight += edge_w
        
    # return weight
    return weight


# make sure the perfect matching is minimum cost by checking and comparing all matchings
def improve_matching(G, M):
        
    # get min # expected edges
    min_edges = len(list(G.nodes))/2
    
    # make a copy of G so it won't be directly affected
    G_copy = G.copy()
    
    # make M the min M
    min_M = M
    
    # and len(new_M) == len(list(G.nodes))/2
    
    # get inital min weight
    min_weight = get_M_weight(G, M)
   
    # remove the inital matching edges from the graph
    G_copy.remove_edges_from(M)
    
    # while the graph still have edges
    while len(list(G_copy.edges)) > 0:
        
        # get new set of matching from remaining edges
        new_M = path_growing(G_copy, min_edges)
        
        # remove edges from new matchings from graph
        G_copy.remove_edges_from(new_M)
        
        # get the total weight of new matching set
        new_weight = get_M_weight(G, new_M)
     
        # update min_M and min_weight if new matching is less than current min
        if new_weight < min_weight:
            min_M = new_M
            min_weight = new_weight
     
    # return perfect matching with minimum cost
    return min_M

#### USE THIS TO FIND MIN PERFECT MST, G IS OG GRAPH AND MST_EDGES IS ALISHA"S OUTPUT FOR MINIMUM SPANNING TREE
def find_min_perfect_matching(G, MST_edges):
    
    # get list of odd degreee vertices in MST
    odd_v_list = get_odd_degree_vertices(MST_edges)
    
    # make a complete graph from the vertices
    comp_graph = get_subgraph(G, odd_v_list)
    
    # get the expected number of edges from perfect matchings 
    expected_n_edges = len(list(comp_graph.nodes))/2
    
    # find initial perfect matching set
    init_m = path_growing(comp_graph, expected_n_edges)
    
    # get perfect matching with minimum cost
    final_m = improve_matching(comp_graph, init_m)
    
    # return perfect matching with minimum cost
    return final_m
    