import math
import networkx as nx
import os

class Data():
    
    def __init__(self):
            self.cities = {}
            self.cnames = []
    
    def data(self):
        
        file = open(os.path.abspath('citydata.txt'), 'r')
        for line in file:
            num = line.split(",")[0]
            cityname = line.split(",")[1]
            self.cnames.append((num,cityname))
            lat = line.split(",")[2]
            long = line.split(",")[3]
            long = long[:-1]
            self.cities[num] = (int(lat), int(long))
            
        return
    
    def usr_input(self, sel_cities):
        gr = nx.Graph()
       
        for city1 in sel_cities:
            for city2 in sel_cities:
                if city1 != city2:
                    d1 = self.cities[city1] 
                    d2 = self.cities[city2]
                    result = round(math.dist(d1, d2), 2)
                    
                    gr.add_edge(d1, d2, weight=result)
         
        
        return gr
        