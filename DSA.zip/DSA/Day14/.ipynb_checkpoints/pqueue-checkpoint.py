import heapq

class PriorityQueue():
    
    def __init__(self):
        self.items = []
        self.true_pri = {}
        
    def put(self, pri, item):
        # put the item in the heap with the new priority
        heapq.heappush(self.items, (pri, item))
        
        # update our "correct" priority values
        if item in self.true_pri:
            old_pri = self.true_pri[item]
            self.true_pri[item] = min(old_pri, pri)
        else:
            self.true_pri[item] = pri
            
    def pop(self):
        if len(self.items) == 0:
            return None,None
        pri, item = heapq.heappop(self.items)
        
        while pri != self.true_pri[item]:
            if len(self.items) == 0:
                return None,None
            pri, item = heapq.heappop(self.items)
        
        return pri,item
    
    def size(self):
        return len(self.items)