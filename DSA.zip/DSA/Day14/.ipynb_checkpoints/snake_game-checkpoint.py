import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"

import pygame
import numpy as np
import math
from pqueue import PriorityQueue
import networkx as nx

import sys

from heapq import *
 
pygame.init()

# Defining the colors that the snake and food will use.  
white = (255, 255, 255)
black = (0, 0, 0)
red = (255, 0, 0)
blue = (0, 0, 255)
 
# Width of the game board (in tiles). 
WIDTH  = 20
# Height of the game board (in tiles).
HEIGHT = 20

# Size of each tile (in pixels).
STEPSIZE = 50

# How fast the game runs. Higher values are faster. 
CLOCK_SPEED = 2000
 
# Making a pygame display. 
dis = pygame.display.set_mode((WIDTH*STEPSIZE,HEIGHT*STEPSIZE))
pygame.display.set_caption('Snake!')

# Initial variables to store the starting x and y position,
# and whether the game has ended. 
game_over = False 
x1 = 5
y1 = 5
snake_list = [(x1,y1)]
snake_len = 1 
x1_change = old_x1_change = 0       
y1_change = old_y1_change = 0

# PyGame clock object.  
clock = pygame.time.Clock()

food_eaten = True

INF = 9999999999999

# Random obstacles, if desired. 
obstacles = [(np.random.randint(low=0, high=WIDTH),np.random.randint(low=0, high=HEIGHT)) for i in range(int(sys.argv[2]))]

# This method is a wrapper for the various AI methods. 
# right now it just moves the snake randomly regardless
# of the board state, because none of those methods are 
# filled in yet. 
# Bstate is a matrix representing the game board:
### Array cells with a 0 are empty locations. 
### Array cells with a -1 are the body of the snake.
### The cell marked with a -2 is the head of the snake.
### The cell marked with a 1 is the food.
def get_AI_moves(ai_mode, bstate):
    if ai_mode == 'rand':
        return random_AI(bstate)
    elif ai_mode == 'greedy':
        return greedy_AI(bstate)
    elif ai_mode == 'astar':
        return astar_AI(bstate)  
    elif ai_mode == 'dijkstra':
        return dijkstra_AI(bstate)  
    elif ai_mode == 'backt':
        return backt_AI(bstate)    
    else:
        raise NotImplementedError("Not a valid AI mode!\nValid modes are rand, greedy, astar, dijkstra, and backt.")    


# These are the methods you will fill in. 
# Only worry about the method assigned on a given day.
# Each method takes in a game board (as described above), and
# should output a series of moves. Valid moves are: 
# (0,1),(0,-1),(1,0), and (-1,0). This means if you want to
# move in any more complicated way, you need to convert the move
# you want to make into a sequence like this one.
# For example, if I wanted my snake to move +5 in the x direction and +3
# in the y direction, I could return 
# [(0,1),(0,1),(0,1),(0,1),(0,1),(1,0),(1,0),(1,0)].

# Several of these methods demonstrate how to get the source
# and target locations, but currently do not use this information. 

def astar_AI(bstate):
    source = np.array(np.where(bstate == -2))
    target = np.array(np.where(bstate == 1))
    
    obstacles = np.array(np.where(bstate < 0))
    
    xsource = source[0][0]
    ysource = source[1][0]
    
    xtarget = target[0][0]
    ytarget = target[1][0]
    
    start = (xsource, ysource)
    end = (xtarget, ytarget)
    
    gr = nx.grid_graph(bstate.shape)
    
    preds = {start: None}
    dist = {start: 0}
    queue = PriorityQueue()
    
    for i in range(bstate.shape[0]):
        for j in range(bstate.shape[1]):
            if bstate[i,j] == -1:
                gr.remove_node((i,j))
            
            elif bstate[i,j] == -2:
                queue.put(0, (i,j))
    
            else:
                queue.put(INF ,(i,j))
                dist[(i,j)] = INF
    
    current = None
    while queue.size() > 0 and current != end:
        dist_to_current, current = queue.pop()
        
        neighbors = gr.neighbors(current)
        
        for neighbor in neighbors:
            new_dist = dist[current] + 1
            new_pri = new_dist + math.dist(neighbor, end)
            if new_dist < dist[neighbor]:
                queue.put(new_pri, neighbor)
                dist[neighbor] = new_dist
                preds[neighbor] = current        
    
    path = []
    direct = []
    
    if end in preds:
        current = end
        while current is not None:
            path.append(current)
            current = preds[current]
            #moves.insert(0,(new[0] - current[0], new[1] - current[1]))
           # current = new
        path = path[::-1]
        
        for index in range(len(path)-1):
            x = path[index+1][0] - path[index][0]
            y = path[index+1][1] - path[index][1]
            direct.append((x,y))
            
        return direct
            
    else:
        return random_AI(bstate)
    
def backt_AI(bstate):
    source = np.array(np.where(bstate == -2))
    target = np.array(np.where(bstate == 1))
    return random_AI(bstate)
    
def dijkstra_AI(bstate):
    source = np.array(np.where(bstate == -2))
    target = np.array(np.where(bstate == 1))
    return random_AI(bstate)
            
def greedy_AI(bstate):
    source = np.array(np.where(bstate == -2))
    target = np.array(np.where(bstate == 1))
    
    xsource = source[0][0]
    ysource = source[1][0]
    
    xtarget = target[0][0]
    ytarget = target[1][0]
    
    def dist_to_target(move):
        xnew = xsource + move[0]
        ynew = ysource + move[1]
        
        if xnew < 0 or xnew > bstate.shape[0] - 1 or ynew < 0 or ynew > bstate.shape[1] - 1:
            return 99999999
        
        elif bstate[xnew, ynew] < 0:
            return 99999999999
        
        return math.dist((xnew, ynew) , (xtarget, ytarget))
              
    
    poss_moves = [(0,1), (0,-1), (1,0), (-1,0)]
    
    sorted_moves = poss_moves.sort(key=dist_to_target)
      
        
    return [poss_moves[0]]
    
def random_AI(bstate):
    return [[(0,1),(0,-1),(1,0),(-1,0)][np.random.randint(low=0,high=4)]]
    
mode = sys.argv[1]

AI_moves = []

# Don't modify any code below this point!
# This code is not meant to be readable or understandable to you - it's the game
# engine and the particulars of moving the snake according to your AI.
# The particulars of the code below shouldn't matter to your AI code above.
# If you have questions, or if your AI code needs to be able to use any of the below,
# talk to or email Cory.  

while not game_over:


    if food_eaten:   
        fx = np.random.randint(low=0,high=WIDTH)
        fy = np.random.randint(low=0,high=HEIGHT)
        while (fx,fy) in snake_list or (fx,fy) in obstacles:
            fx = np.random.randint(low=0,high=WIDTH)
            fy = np.random.randint(low=0,high=HEIGHT)
        food_eaten = False
        
    dis.fill(white)
    
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_over = True
        if mode == 'human':    
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    x1_change = -1
                    y1_change = 0
                elif event.key == pygame.K_RIGHT:
                    x1_change = 1
                    y1_change = 0
                elif event.key == pygame.K_UP:
                    y1_change = -1
                    x1_change = 0
                elif event.key == pygame.K_DOWN:
                    y1_change = 1
                    x1_change = 0
    if mode != 'human':
        if len(AI_moves) == 0:
            bstate = np.zeros((WIDTH,HEIGHT))
            for xx,yy in snake_list:
                bstate[xx,yy] = -1
            for xx,yy in obstacles:
                bstate[xx,yy] = -1
            bstate[snake_list[-1][0], snake_list[-1][1]] = -2
            bstate[fx,fy] = 1    
            AI_moves = get_AI_moves(mode, bstate)     
        x1_change, y1_change = AI_moves.pop(0)               
    if len(snake_list) > 1 :
        if ((snake_list[-1][0] + x1_change) % WIDTH) == snake_list[-2][0] and ((snake_list[-1][1] + y1_change)% HEIGHT) == snake_list[-2][1]:
            x1_change = old_x1_change
            y1_change = old_y1_change
    x1 += x1_change
    y1 += y1_change          
    
    x1 = x1 % WIDTH
    y1 = y1 % HEIGHT
    
    if x1 == fx and y1 == fy:
        snake_len += 1
        food_eaten = True
    
    snake_list.append((x1,y1))
    snake_list = snake_list[-snake_len:]
    
    if len(list(set(snake_list))) < len(snake_list) or len(set(snake_list).intersection(set(obstacles))) > 0:
        print("You lose! Score: %d" % snake_len)
        game_over = True
    else:
        sncols = np.linspace(.5,1.0, len(snake_list))
        for jj, (xx, yy) in enumerate(snake_list):
            pygame.draw.rect(dis, (0, 255*sncols[jj], 32*sncols[jj]), [xx*STEPSIZE, yy*STEPSIZE, STEPSIZE, STEPSIZE])

        for (xx, yy) in np.cumsum(np.array([[.5,.5],snake_list[-1]] + AI_moves), axis=0)[2:]:
            pygame.draw.circle(dis, red, (xx*STEPSIZE,yy*STEPSIZE), STEPSIZE/4)            
        
        if not food_eaten:
            pygame.draw.rect(dis, red, [fx*STEPSIZE, fy*STEPSIZE, STEPSIZE, STEPSIZE])
        
        for xx, yy in obstacles:
            pygame.draw.rect(dis, blue, [xx*STEPSIZE, yy*STEPSIZE, STEPSIZE, STEPSIZE])
        pygame.display.update()
     
        clock.tick(CLOCK_SPEED)
        
        old_x1_change = x1_change
        old_y1_change = y1_change
 
pygame.quit()
quit()
