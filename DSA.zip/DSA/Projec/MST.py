class MinSpanTree(Graph):
    
    
    def __init__(self):
        self.sourceNode = None
        
        
    def findMinSpan(self, sourceNode):
        pass
    
    def get_distance(self, node1, node2):
        pass
    
    
class Prim(self, graph, mst):
     
        
        def __init__(self):
            pass
        
        
    
    
    