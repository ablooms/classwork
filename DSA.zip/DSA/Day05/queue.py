
class Node():
    def __init__(self, content):
        self.content = content
        self.prev = None
        self.next = None
        
class Queue():
    def __init__(self):
        self.size = 0
        self.head = None
        self.tail = None
    
    def isEmpty(self):
        if self.size > 0:
            return False
        else:
            return True
    
    def enqueue(self, item):
        # need to make a node!
        newNode = Node(item)
        if self.size == 0:  
            # need to designate a head
            self.head = newNode
        else:
            self.tail.next = newNode
            newNode.prev = self.tail
        # update the size of the queue
        self.size += 1
        self.tail = newNode
            
    def dequeue(self):
        # if the queue is empty return none
        if self.size == 0:
            return None
       # else, get the content of the headpointer
       # set the head to be the next thing in the queue
       # decrease the size count by 1 and return the content
        else:
            content = self.head.content
            self.head = self.head.next
            self.size -= 1
            return content
        
    def peek(self):
        # see the top (head) content
        return self.head.content
    
if __name__ == '__main__':  
    queue = Queue()
    assert queue.isEmpty()
    queue.enqueue(1)
    queue.enqueue(2)
    queue.enqueue(3)
    
    assert queue.dequeue() == 1
    assert queue.dequeue() == 2
    assert queue.dequeue() == 3
    
    assert queue.isEmpty()
