
class Node():
    def __init__(self, content):
        # all the data we need for a node
        self.content = content
        self.prev = None
        self.next = None


class Stack():
    def __init__(self):
        # need to know the size and the head of the stack
        # and need to initialize an empty stack w 0's and nones
        self.size = 0
        self.head = None
    
    def isEmpty(self):
        # check if the stack is empty or not
        if self.size != 0:
            return False
        else:
            return True
    
    def push(self, item):
        # need to make a new node
        newNode = Node(item)
        # if the stack is empty, make the newNode the head
        if self.size == 0:
            self.head = newNode
         
        else:
            # have to change what's considered previouse and next
            self.head.prev = newNode
            newNode.next = self.head          
            # change the head of the stack
            self.head = newNode
        
        # update the size of the stack
        self.size += 1
            
    def pop(self):
        # can't pop if the list is empty :P
        if self.size == 0:
            return None
                   
        # else, save the content of the head of the stack
        # change the head of the stack, decrease size and return content
        else:
            content = self.head.content
            self.head = self.head.next
            self.size -= 1
            return content
        
    # view the head of the stack
    def peek(self):
        return self.head.content
        
if __name__ == '__main__':      
    stack = Stack()
    assert stack.isEmpty()
    stack.push(1)
    stack.push(2)
    stack.push(3)
        
    assert stack.pop() == 3
    assert stack.pop() == 2
    assert stack.pop() == 1
    
    assert stack.isEmpty() 
